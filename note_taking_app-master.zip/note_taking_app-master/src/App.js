import  HomeMainPage from './Components/HomeMainPage/HomeMainPage';
import './App.css';

function App() {
  return (
    <>
    <HomeMainPage/>
    </>
  );
}

export default App;
